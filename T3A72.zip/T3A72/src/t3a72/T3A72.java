package t3a72;
import java.util.Scanner;
public class T3A72 {

    public static void main(String[] args) {
        
        Scanner leer=new Scanner(System.in);
        
        System.out.println("Ingresa 10 numeros impares: ");
       
        int num1=leer.nextInt();
        int num2=leer.nextInt();
        int num3=leer.nextInt();
        int num4=leer.nextInt();
        int num5=leer.nextInt();
        int num6=leer.nextInt();
        int num7=leer.nextInt();
        int num8=leer.nextInt();
        int num9=leer.nextInt();
        int num10=leer.nextInt();
        int resultado= num1 + num2 + num3 + num4 + num5 + num6+ num7 + num8 + num9 + num10;
        
        if ((num1)!=0 & (num2)!=0 & (num3)!=0 & (num4)!=0 & (num5)!=0 & (num6)!=0 & (num7)!=0 & (num8)!=0 & (num9)!=0 & (num10)!=0){
            System.out.println("El producto es: " + resultado/10);
        
        }
       
    }
    
}
