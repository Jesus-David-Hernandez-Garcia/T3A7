package t3a74;

import java.util.Scanner;

public class T3A74 {

    public static void main(String[] args) {

        Scanner obj;
        obj=new Scanner (System.in);
        int i;
        int altura=0;
        int altura1=0;       
        int edad=0;
        int edad1=0; 
        for (i=0;i<=3;i=i+1){
            System.out.println("Escribe tu edad");
            edad=obj.nextInt();
            obj.nextLine();
            if (edad>18){
                edad1++;
            }
           
            System.out.println ("Escribe tu altura sin punto decimal");
            altura=obj.nextInt();
            obj.nextLine ();
            if (altura>175){
                altura1++;
            }
          
            }
            System.out.println ("los alumnos que miden mas de 1.75 son " +  altura1);
    
            
    }
}
