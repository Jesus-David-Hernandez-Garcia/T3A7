package t3a73;

import java.util.Scanner;

public class T3A73 {

    public static void main(String[] args) {

        Scanner obj=new Scanner (System.in);
        int trabajador;
        int resultado=0;
        for (trabajador=0;trabajador<=4;trabajador=trabajador+1){
            System.out.println("Escriba su nombre: ");
            String nombre=obj.next();
            System.out.println("cual es su salario: ");
            int salario=obj.nextInt();
            resultado= resultado+salario;
            
        }
        int promedio ;
       promedio= resultado /5;
        System.out.println("Promedio de los salarios es: " + promedio);
    }
    
    
}
