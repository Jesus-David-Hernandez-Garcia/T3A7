package ciclofor;
import java.util.Scanner;

public class CicloFor {

    public static void main(String[] args) {
    ciclo ();}
    
    public static void ciclo() {
    Scanner obj = new Scanner (System.in);
            System.out.println("Inicio: ");
            int inicio = obj.nextInt();
            
            System.out.println("Limite: ");
            int limite = obj.nextInt();
            
            System.out.println("Incremento: ");
            int incremento = obj.nextInt();
            
            if (inicio < limite ){
                for (int numero=inicio; numero <= limite; numero +=incremento){
                    System.out.println("Numero actual es " + numero);
                }
            }else if (limite < inicio){
                for (int numero = inicio; numero >= limite; numero -= incremento){
                    System.out.println("Numero actual es " + numero);
                }
            }else{
                System.out.println("El inicio es identico al limite " + inicio + "-" + limite);
            }
        }
    }

